import { Button } from "@/components/ui/button";
import {
  CheckCircle,
  TrendingUp,
  Shield,
  Clock,
  Users,
  Award,
  ArrowRight,
  Menu,
  X,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import { Background3D } from "@/components/3d-background";

export default function Index() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background relative">
      <Background3D />

      {/* Navigation */}
      <nav className="border-b border-border/50 bg-white/70 backdrop-blur-md supports-[backdrop-filter]:bg-white/50 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">CW</span>
              </div>
              <span className="text-xl font-bold text-foreground hidden sm:inline">
                CreditWise
              </span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-foreground hover:text-primary transition">
                Features
              </a>
              <a href="#process" className="text-foreground hover:text-primary transition">
                How It Works
              </a>
              <a href="#why" className="text-foreground hover:text-primary transition">
                Why Us
              </a>
            </div>

            {/* CTA Buttons */}
            <div className="hidden md:flex items-center gap-4">
              <Button variant="outline">Sign In</Button>
              <Link to="/loan-calculator">
                <Button>Get Started</Button>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4 flex flex-col gap-4">
              <a href="#features" className="text-foreground hover:text-primary">
                Features
              </a>
              <a href="#process" className="text-foreground hover:text-primary">
                How It Works
              </a>
              <a href="#why" className="text-foreground hover:text-primary">
                Why Us
              </a>
              <div className="flex gap-2 pt-2">
                <Button variant="outline" className="flex-1">
                  Sign In
                </Button>
                <Link to="/loan-calculator" className="flex-1">
                  <Button className="w-full">Get Started</Button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-40 bg-gradient-to-b from-white/50 via-blue-50/30 to-transparent">
        <div className="absolute inset-0 -z-10">
          {/* Animated gradient orbs */}
          <div className="absolute top-20 right-1/4 w-96 h-96 bg-gradient-to-br from-primary/20 to-secondary/10 rounded-full blur-3xl animate-pulse opacity-60" />
          <div className="absolute bottom-20 left-1/3 w-96 h-96 bg-gradient-to-tr from-secondary/15 to-primary/10 rounded-full blur-3xl animate-pulse opacity-60 animation-delay-2000" />
          <div className="absolute top-1/2 -right-32 w-72 h-72 bg-blue-400/10 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="flex flex-col gap-8 relative z-10">
              <div className="space-y-6">
                {/* Badge */}
                <div className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-primary/10 to-secondary/10 text-primary border border-primary/30 w-fit backdrop-blur-sm hover:border-primary/50 transition-all">
                  <Zap className="w-4 h-4" />
                  <span className="text-sm font-semibold">Next-Gen Lending Platform</span>
                </div>

                {/* Main Heading */}
                <div>
                  <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight text-foreground mb-2">
                    Smart Loans,
                  </h1>
                  <h2 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent animate-pulse">
                    Smarter Decisions
                  </h2>
                </div>

                {/* Description */}
                <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl leading-relaxed">
                  Experience the future of lending with AI-powered credit analysis. Get instant approvals, transparent rates, and personalized solutions—all designed to empower your financial journey.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link to="/loan-calculator" className="flex-1 sm:flex-none">
                  <Button size="lg" className="w-full sm:w-auto gap-2 bg-gradient-to-r from-primary to-secondary hover:shadow-lg hover:shadow-primary/20 transition-all duration-300 transform hover:scale-105">
                    Start Your Application
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="backdrop-blur-sm border-primary/20 hover:border-primary/50 hover:bg-white/80">
                  Explore Features
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-8">
                {[
                  { value: "50K+", label: "Happy Customers" },
                  { value: "₹500Cr", label: "Loans Approved" },
                  { value: "24hrs", label: "Quick Approval" },
                ].map((stat, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-white/40 backdrop-blur-md border border-white/60 hover:bg-white/60 transition-all"
                  >
                    <div className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                      {stat.value}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Visual - Enhanced 3D Card */}
            <div className="relative h-96 lg:h-full min-h-96 group">
              {/* Background glow effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-secondary/20 rounded-3xl blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              {/* Main card with glassmorphism */}
              <div className="relative h-full bg-gradient-to-br from-white/70 via-blue-50/50 to-white/70 rounded-3xl border border-white/60 backdrop-blur-xl shadow-2xl hover:shadow-3xl transition-all duration-500 flex items-center justify-center overflow-hidden">
                {/* Animated gradient background */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 opacity-50" />

                <div className="relative space-y-4 p-8">
                  {[
                    "⚡ Instant Eligibility Check",
                    "💰 Transparent Interest Rates",
                    "🔒 Secure Credit Analysis",
                    "👨‍💼 Expert Financial Guidance",
                  ].map((feature, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-3 p-4 rounded-xl bg-white/60 backdrop-blur-md border border-white/70 hover:bg-white/80 hover:border-primary/30 transition-all duration-300 transform hover:translate-x-2"
                    >
                      <CheckCircle className="w-5 h-5 text-secondary flex-shrink-0" />
                      <span className="text-sm font-medium text-foreground">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 lg:py-32 bg-gradient-to-b from-transparent via-white/30 to-blue-50/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary border border-primary/20 mb-6">
              <Zap className="w-4 h-4" />
              <span className="text-sm font-semibold">Why We're Different</span>
            </div>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6">
              Why Choose CreditWise?
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Next-generation loan management powered by AI, designed for your financial success
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Clock,
                title: "Lightning Fast",
                description: "Get approved in minutes with our instant evaluation system",
                color: "from-blue-500/20 to-blue-500/5",
              },
              {
                icon: Shield,
                title: "Secure & Safe",
                description:
                  "Bank-grade encryption protects your personal and financial data",
                color: "from-green-500/20 to-green-500/5",
              },
              {
                icon: TrendingUp,
                title: "Competitive Rates",
                description: "Best interest rates in the market with zero hidden charges",
                color: "from-purple-500/20 to-purple-500/5",
              },
              {
                icon: Users,
                title: "24/7 Support",
                description: "Our expert team is always ready to assist you anytime",
                color: "from-orange-500/20 to-orange-500/5",
              },
              {
                icon: Award,
                title: "Industry Leading",
                description:
                  "Recognized for excellence and customer satisfaction across India",
                color: "from-pink-500/20 to-pink-500/5",
              },
              {
                icon: CheckCircle,
                title: "Flexible Terms",
                description: "Choose loan tenure and EMI that fit your budget perfectly",
                color: "from-cyan-500/20 to-cyan-500/5",
              },
            ].map((feature, idx) => {
              const IconComponent = feature.icon;
              return (
                <div
                  key={idx}
                  className={`group relative p-8 rounded-2xl bg-gradient-to-br ${feature.color} backdrop-blur-md border border-white/50 hover:border-primary/30 hover:shadow-xl transition-all duration-300 overflow-hidden`}
                >
                  {/* Gradient overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-white/0 to-white/0 group-hover:from-white/10 group-hover:to-white/5 transition-all duration-300" />

                  <div className="relative">
                    <div className="w-14 h-14 rounded-xl bg-white/60 backdrop-blur-sm flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                      <IconComponent className="w-7 h-7 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="process" className="py-20 lg:py-32 relative bg-gradient-to-b from-blue-50/50 to-white/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 text-secondary border border-secondary/20 mb-6">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-semibold">4 Simple Steps</span>
            </div>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6">
              Your Path to Fast Loans
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              From application to funds in your account – streamlined, simple, and secure
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
            {/* Connection line for desktop */}
            <div className="hidden md:block absolute top-8 left-[12.5%] right-[12.5%] h-1 bg-gradient-to-r from-secondary via-secondary to-transparent" />

            {[
              {
                step: 1,
                title: "Apply Online",
                description: "Fill out a simple form with your basic information",
                icon: "📝",
              },
              {
                step: 2,
                title: "Instant Eligibility",
                description:
                  "Get instant feedback on your loan eligibility and amount",
                icon: "⚡",
              },
              {
                step: 3,
                title: "Document Upload",
                description: "Submit required documents for quick verification",
                icon: "📄",
              },
              {
                step: 4,
                title: "Funds Disbursed",
                description: "Get funds transferred directly to your account",
                icon: "💰",
              },
            ].map((item, idx) => (
              <div key={idx} className="relative">
                <div className="flex flex-col items-center text-center group">
                  {/* Step circle */}
                  <div className="relative mb-6">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-secondary to-primary flex items-center justify-center text-white font-bold text-2xl shadow-xl group-hover:shadow-2xl group-hover:scale-110 transition-all duration-300 relative z-10 bg-white border-4 border-gradient-to-r from-primary to-secondary">
                      <div className="text-3xl">{item.icon}</div>
                    </div>
                    {/* Glow effect */}
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-secondary/30 to-primary/30 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-bold text-foreground mb-2">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {item.description}
                  </p>

                  {/* Step number badge */}
                  <div className="mt-4 inline-flex items-center justify-center w-8 h-8 rounded-full bg-secondary/10 text-secondary font-bold text-sm">
                    {item.step}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section id="why" className="py-20 lg:py-32 bg-gradient-to-br from-primary/10 via-secondary/10 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { label: "Loans Processed", value: "₹500+ Cr" },
              { label: "Customers Served", value: "50,000+" },
              { label: "Approval Rate", value: "95%+" },
              { label: "Average Time", value: "24 Hours" },
            ].map((stat, idx) => (
              <div key={idx} className="text-center p-8 rounded-2xl bg-background/50 backdrop-blur border border-border">
                <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">
                  {stat.value}
                </div>
                <div className="text-muted-foreground text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Ready to Get Your Loan?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who have received their loans through
            CreditWise. Start your journey towards financial freedom today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/loan-calculator">
              <Button size="lg" className="gap-2">
                Apply Now
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Button size="lg" variant="outline">
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold">CW</span>
                </div>
                <span className="font-bold text-foreground">CreditWise</span>
              </div>
              <p className="text-muted-foreground text-sm">
                Empowering millions with smart lending solutions
              </p>
            </div>

            <div>
              <h4 className="font-bold text-foreground mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary transition">
                    Personal Loans
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition">
                    Business Loans
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition">
                    Home Loans
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-foreground mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary transition">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition">
                    Careers
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-foreground mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary transition">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8">
            <p className="text-center text-sm text-muted-foreground">
              © 2024 CreditWise. All rights reserved. | Made with ❤️ for your financial
              freedom
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
