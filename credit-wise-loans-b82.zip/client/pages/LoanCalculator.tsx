import { Button } from "@/components/ui/button";
import { ArrowLeft, Calculator } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

export default function LoanCalculator() {
  const [loanAmount, setLoanAmount] = useState(500000);
  const [interestRate, setInterestRate] = useState(8.5);
  const [loanTerm, setLoanTerm] = useState(60);

  // Calculate EMI
  const monthlyRate = interestRate / 12 / 100;
  const emi =
    (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, loanTerm)) /
    (Math.pow(1 + monthlyRate, loanTerm) - 1);
  const totalPayable = emi * loanTerm;
  const totalInterest = totalPayable - loanAmount;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Link
            to="/"
            className="p-2 hover:bg-muted rounded-lg transition"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold text-foreground">Loan EMI Calculator</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Calculator Section */}
          <div className="space-y-8">
            {/* Loan Amount */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Loan Amount: ₹{loanAmount.toLocaleString()}
              </label>
              <input
                type="range"
                min="100000"
                max="5000000"
                step="10000"
                value={loanAmount}
                onChange={(e) => setLoanAmount(Number(e.target.value))}
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>₹1 Lakh</span>
                <span>₹50 Lakh</span>
              </div>
            </div>

            {/* Interest Rate */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Interest Rate (p.a.): {interestRate.toFixed(2)}%
              </label>
              <input
                type="range"
                min="4"
                max="15"
                step="0.1"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>4%</span>
                <span>15%</span>
              </div>
            </div>

            {/* Loan Term */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Loan Tenure: {loanTerm} months ({(loanTerm / 12).toFixed(1)} years)
              </label>
              <input
                type="range"
                min="12"
                max="120"
                step="1"
                value={loanTerm}
                onChange={(e) => setLoanTerm(Number(e.target.value))}
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>1 Year</span>
                <span>10 Years</span>
              </div>
            </div>

            <Button size="lg" className="w-full gap-2">
              <Calculator className="w-4 h-4" />
              Apply Now
            </Button>
          </div>

          {/* Results Section */}
          <div className="space-y-4">
            <div className="p-8 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20">
              <h2 className="text-lg font-bold text-foreground mb-8">Loan Summary</h2>

              <div className="space-y-6">
                {/* Monthly EMI */}
                <div className="p-4 rounded-lg bg-background border border-border">
                  <p className="text-sm text-muted-foreground">Monthly EMI</p>
                  <p className="text-3xl font-bold text-primary">
                    ₹{emi.toLocaleString("en-IN", { maximumFractionDigits: 0 })}
                  </p>
                </div>

                {/* Total Interest */}
                <div className="p-4 rounded-lg bg-background border border-border">
                  <p className="text-sm text-muted-foreground">Total Interest Payable</p>
                  <p className="text-3xl font-bold text-secondary">
                    ₹{totalInterest.toLocaleString("en-IN", { maximumFractionDigits: 0 })}
                  </p>
                </div>

                {/* Total Amount */}
                <div className="p-4 rounded-lg bg-background border border-border">
                  <p className="text-sm text-muted-foreground">Total Amount Payable</p>
                  <p className="text-3xl font-bold text-foreground">
                    ₹{totalPayable.toLocaleString("en-IN", { maximumFractionDigits: 0 })}
                  </p>
                </div>

                {/* Loan Details */}
                <div className="space-y-3 pt-4 border-t border-border">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Principal Amount</span>
                    <span className="font-medium">
                      ₹{loanAmount.toLocaleString("en-IN")}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Rate of Interest</span>
                    <span className="font-medium">{interestRate.toFixed(2)}% p.a.</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Loan Duration</span>
                    <span className="font-medium">{loanTerm} months</span>
                  </div>
                </div>
              </div>
            </div>

            <p className="text-xs text-muted-foreground text-center">
              *This is an approximate calculation. Actual EMI may vary based on processing
              fees and other charges.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
