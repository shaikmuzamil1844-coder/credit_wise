import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  CreditCard,
  Clock,
  CheckCircle,
  AlertCircle,
  TrendingUp,
  Download,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function Dashboard() {
  // Mock loan applications
  const loans = [
    {
      id: 1,
      amount: 500000,
      status: "Approved",
      rate: 8.5,
      emi: 10250,
      disbursalDate: "2024-02-15",
      statusColor: "bg-green-100 text-green-800",
      icon: CheckCircle,
    },
    {
      id: 2,
      amount: 300000,
      status: "Under Review",
      rate: 8.2,
      emi: 6150,
      expectedDate: "2024-02-20",
      statusColor: "bg-yellow-100 text-yellow-800",
      icon: Clock,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link
              to="/"
              className="p-2 hover:bg-muted rounded-lg transition"
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-2xl font-bold text-foreground">My Dashboard</h1>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Welcome back,</p>
            <p className="font-medium text-foreground">Rahul Kumar</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="p-6 rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20">
            <CreditCard className="w-8 h-8 text-primary mb-3" />
            <p className="text-sm text-muted-foreground mb-2">Total Loans</p>
            <p className="text-3xl font-bold text-foreground">2</p>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-br from-secondary/10 to-secondary/5 border border-secondary/20">
            <TrendingUp className="w-8 h-8 text-secondary mb-3" />
            <p className="text-sm text-muted-foreground mb-2">Total Amount</p>
            <p className="text-3xl font-bold text-foreground">₹8 Lakh</p>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-br from-blue-500/10 to-blue-500/5 border border-blue-500/20">
            <AlertCircle className="w-8 h-8 text-blue-600 mb-3" />
            <p className="text-sm text-muted-foreground mb-2">Avg. Interest Rate</p>
            <p className="text-3xl font-bold text-foreground">8.35%</p>
          </div>
        </div>

        {/* Loans List */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">My Loans</h2>
            <Link to="/loan-calculator">
              <Button>New Application</Button>
            </Link>
          </div>

          <div className="space-y-4">
            {loans.map((loan) => {
              const StatusIcon = loan.icon;
              return (
                <div
                  key={loan.id}
                  className="p-6 rounded-2xl bg-background border border-border hover:border-primary/30 transition-all"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                        <StatusIcon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-bold text-foreground mb-1">
                          Personal Loan - ₹{loan.amount.toLocaleString("en-IN")}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          Loan ID: CW-{String(loan.id).padStart(4, "0")}
                        </p>
                      </div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${loan.statusColor}`}>
                      {loan.status}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 py-4 border-y border-border">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Monthly EMI</p>
                      <p className="font-bold text-foreground">
                        ₹{loan.emi.toLocaleString("en-IN")}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Interest Rate</p>
                      <p className="font-bold text-foreground">{loan.rate}%</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">
                        {loan.status === "Approved" ? "Disbursal Date" : "Expected Date"}
                      </p>
                      <p className="font-bold text-foreground">
                        {loan.status === "Approved" ? loan.disbursalDate : loan.expectedDate}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Progress</p>
                      <p className="font-bold text-foreground">
                        {loan.status === "Approved" ? "100%" : "75%"}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Download className="w-4 h-4" />
                      Documents
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl p-8 border border-primary/20">
          <h2 className="text-2xl font-bold text-foreground mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="h-auto py-4">
              <div className="text-left">
                <p className="font-bold text-foreground">Check Eligibility</p>
                <p className="text-sm text-muted-foreground">
                  See if you qualify for a new loan
                </p>
              </div>
            </Button>
            <Button variant="outline" className="h-auto py-4">
              <div className="text-left">
                <p className="font-bold text-foreground">Download Statement</p>
                <p className="text-sm text-muted-foreground">
                  Get your loan statement in PDF
                </p>
              </div>
            </Button>
            <Button variant="outline" className="h-auto py-4">
              <div className="text-left">
                <p className="font-bold text-foreground">Contact Support</p>
                <p className="text-sm text-muted-foreground">
                  Chat with our support team
                </p>
              </div>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
